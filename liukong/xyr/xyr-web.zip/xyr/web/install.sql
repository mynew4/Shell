-- phpMyAdmin SQL Dump
-- version 4.0.10.15
-- http://www.phpmyadmin.net
--
-- 主机: m.xiaoyangren.net
-- 生成日期: 2017-03-08 00:00:00
-- 服务器版本: 5.5.50-MariaDB
-- PHP 版本: 5.4.45

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 插入流量卫士管理员
--
CREATE TABLE IF NOT EXISTS `app_admin` (
  `id` int(11) NOT NULL,
  `op` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `app_admin` (`id`, `op`, `username`, `password`) VALUES
(1, '0', 'admin', 'admin');

-- --------------------------------------------------------

--
-- 表的结构 `alipay`
--

CREATE TABLE IF NOT EXISTS `alipay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `partner` text NOT NULL,
  `alikey` text NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `alipay`
--

INSERT INTO `alipay` (`id`, `partner`, `alikey`, `url`) VALUES
(1, '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `auth_config`
--

CREATE TABLE IF NOT EXISTS `auth_config` (
  `id` varchar(80) NOT NULL DEFAULT '1',
  `gg` text,
  `ggs` text,
  `dl0` float DEFAULT NULL,
  `dl1` float DEFAULT NULL COMMENT 'vip1',
  `dl2` float DEFAULT NULL COMMENT 'vip2',
  `dl3` float DEFAULT NULL COMMENT 'vip3',
  `dl4` float DEFAULT NULL COMMENT 'vip4',
  `dl5` float DEFAULT NULL COMMENT 'vip5',
  `dls0` float NOT NULL,
  `dls1` float NOT NULL,
  `dls2` float NOT NULL,
  `dls3` float NOT NULL,
  `dls4` float NOT NULL,
  `dls5` float NOT NULL,
  `member_reg` int(2) NOT NULL DEFAULT '0',
  `regok` int(11) DEFAULT NULL,
  `activeok` int(11) DEFAULT NULL,
  `ok` int(11) DEFAULT NULL,
  `shopUrl` text NOT NULL,
  `shopCode` text NOT NULL,
  `daili_cash` float NOT NULL,
  `reg_cash` float NOT NULL,
  `user_cash` float NOT NULL,
  `qian` float NOT NULL,
  `user_endtime` int(11) NOT NULL,
  `wx0` float NOT NULL,
  `wx1` float NOT NULL,
  `wx2` float NOT NULL,
  `wx3` float NOT NULL,
  `wx4` float NOT NULL,
  `wx5` float NOT NULL,
  `kmtype` float NOT NULL DEFAULT '1' COMMENT '1默认关闭自主设计套餐',
  `down` float DEFAULT '1' COMMENT '1默认关闭下载',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `auth_config`
--

INSERT INTO `auth_config` (`id`, `gg`, `ggs`, `dl0`, `dl1`, `dl2`, `dl3`, `dl4`, `dl5`, `dls0`, `dls1`, `dls2`, `dls3`, `dls4`, `dls5`, `member_reg`, `regok`, `activeok`, `ok`, `shopUrl`, `shopCode`, `daili_cash`, `reg_cash`, `user_cash`, `qian`, `user_endtime`, `wx0`, `wx1`, `wx2`, `wx3`, `wx4`, `wx5`, `kmtype`, `down`) VALUES
('1', '欢迎使用代理中心！', '欢迎使用会员中心！', 0, 0, 0, 0, 0, 0, 4, 3.5, 3, 2.5, 2, 1.5, 0, 0, 0, 2, 'http://www.xiaoyangren.net/', '', 10, 20971500, 52428800, 10485800, 1, 16, 14, 12, 10, 8, 6, 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `auth_daili`
--

CREATE TABLE IF NOT EXISTS `auth_daili` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tj_rmb` decimal(11,2) NOT NULL,
  `tj_user` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  `vip` int(11) DEFAULT NULL,
  `kmlist` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `regdate` datetime DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `qq` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `buy` text NOT NULL,
  `buy2` text NOT NULL,
  `income` decimal(11,2) NOT NULL DEFAULT '0.00',
  `adtext` text NOT NULL,
  `adimg` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `auth_daili`
--

INSERT INTO `auth_daili` (`id`, `tj_rmb`, `tj_user`, `user`, `pass`, `rmb`, `vip`, `kmlist`, `active`, `regdate`, `name`, `qq`, `tel`, `buy`, `buy2`, `income`, `adtext`, `adimg`) VALUES
(0, 0.00, '', 'xyr', 'xyr', 0.00, 5, NULL, 1, '2017-03-08 00:00:00', '管理员', '123123', '123456', 'http://www.xiaoyangren.net/', '', 0.00, '', '');

-- --------------------------------------------------------

--
-- 表的结构 `auth_fwq`
--

CREATE TABLE IF NOT EXISTS `auth_fwq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `ipport` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `auth_fwq`
--

INSERT INTO `auth_fwq` (`id`, `name`, `ipport`, `time`) VALUES
(1, '本机服务器', 'localhost', '2017-03-08 00:00:00');

-- --------------------------------------------------------

--
-- 表的结构 `auth_kms`
--

CREATE TABLE IF NOT EXISTS `auth_kms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` tinyint(1) NOT NULL DEFAULT '1',
  `daili` int(11) NOT NULL DEFAULT '0',
  `km` varchar(64) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  `values` decimal(11,2) DEFAULT NULL,
  `money` decimal(11,2) DEFAULT '0.00',
  `isuse` tinyint(1) DEFAULT '0',
  `user` varchar(50) DEFAULT NULL,
  `usetime` datetime DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `kmtype_id` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `km` (`km`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;

-- --------------------------------------------------------

--
-- 表的结构 `auth_log`
--

CREATE TABLE IF NOT EXISTS `auth_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;

-- --------------------------------------------------------

--
-- 表的结构 `banner`
--

CREATE TABLE IF NOT EXISTS `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img1` text CHARACTER SET utf8 NOT NULL,
  `tit1` text CHARACTER SET utf8 NOT NULL,
  `info1` text CHARACTER SET utf8 NOT NULL,
  `img2` text CHARACTER SET utf8 NOT NULL,
  `tit2` text CHARACTER SET utf8 NOT NULL,
  `info2` text CHARACTER SET utf8 NOT NULL,
  `img3` text CHARACTER SET utf8 NOT NULL,
  `tit3` text CHARACTER SET utf8 NOT NULL,
  `info3` text CHARACTER SET utf8 NOT NULL,
  `daili` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `banner`
--

INSERT INTO `banner` (`id`, `img1`, `tit1`, `info1`, `img2`, `tit2`, `info2`, `img3`, `tit3`, `info3`, `daili`) VALUES
(0, 'http://localhost/web/images/slide_1.jpg', '超实惠流量冲浪新时代', '抵制高价流量，让你使用专用的流量服务，从而价格远远低于运营商，安全快捷！', 'http://localhost/web/images/slide_2.jpg', '支持IOS6-IOS10系统', '一次安装永久支持续费，VPN连接100M服务器转接', 'http://localhost/web/images/slide_3.jpg', '安卓系统完美支持', '操作人性化，流量软件上手很简单，使用仅需简单操作几步', 0);

-- --------------------------------------------------------

--
-- 表的结构 `kmtype`
--

CREATE TABLE IF NOT EXISTS `kmtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `days` float NOT NULL,
  `maxll` float NOT NULL,
  `dlid` float NOT NULL,
  `km_rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  `i` float NOT NULL COMMENT '代理充值套餐',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

-- --------------------------------------------------------

--
-- 表的结构 `line`
--

CREATE TABLE IF NOT EXISTS `line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `content` text NOT NULL,
  `type` text NOT NULL,
  `group` text NOT NULL,
  `show` int(11) NOT NULL,
  `label` text NOT NULL,
  `time` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;

-- --------------------------------------------------------

--
-- 表的结构 `line_grop`
--

CREATE TABLE IF NOT EXISTS `line_grop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_bin NOT NULL,
  `show` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `line_grop`
--

INSERT INTO `line_grop` (`id`, `name`, `show`, `order`) VALUES
(1, '中国移动', 1, 1),
(2, '中国联通', 1, 1),
(3, '中国电信', 1, 1),
(4, '其他线路', 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `open`
--

CREATE TABLE IF NOT EXISTS `open` (
  `id` varchar(50) NOT NULL,
  `type` float NOT NULL,
  `name` varchar(50) NOT NULL,
  `mo` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `openvpn`
--

CREATE TABLE IF NOT EXISTS `openvpn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iuser` varchar(16) NOT NULL,
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `i` int(1) NOT NULL,
  `starttime` varchar(30) DEFAULT NULL,
  `endtime` int(11) DEFAULT '0',
  `dlid` int(11) DEFAULT NULL,
  `fwqid` int(11) DEFAULT '1',
  `notes` varchar(255) DEFAULT NULL,
  `tian` float NOT NULL COMMENT 'xiaoyangren.net',
  `qian_date` date NOT NULL,
  `qian_num` float NOT NULL,
  `tj_user` text CHARACTER SET utf8 NOT NULL,
  `tj_ok` float NOT NULL,
  `by` int(11) NOT NULL DEFAULT '0' COMMENT '0默认关闭该会员包月模式',
  PRIMARY KEY (`id`),
  KEY `iuser` (`iuser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `website`
--

CREATE TABLE IF NOT EXISTS `website` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `logo` text CHARACTER SET utf8 NOT NULL,
  `title` text CHARACTER SET utf8 NOT NULL,
  `app1` text CHARACTER SET utf8 NOT NULL,
  `app2` text CHARACTER SET utf8 NOT NULL,
  `qq` text CHARACTER SET utf8 NOT NULL,
  `tel` text CHARACTER SET utf8 NOT NULL,
  `ipinfo` text CHARACTER SET utf8 NOT NULL,
  `appleid1` text CHARACTER SET utf8 NOT NULL,
  `appleps1` text CHARACTER SET utf8 NOT NULL,
  `appleid2` text CHARACTER SET utf8 NOT NULL,
  `appleps2` text CHARACTER SET utf8 NOT NULL,
  `appleid3` text CHARACTER SET utf8 NOT NULL,
  `appleps3` text CHARACTER SET utf8 NOT NULL,
  `and_img1` text CHARACTER SET utf8 NOT NULL,
  `and_img2` text CHARACTER SET utf8 NOT NULL,
  `and_img3` text CHARACTER SET utf8 NOT NULL,
  `and_img4` text CHARACTER SET utf8 NOT NULL,
  `jia1` text CHARACTER SET utf8 NOT NULL,
  `jia2` text CHARACTER SET utf8 NOT NULL,
  `jia3` text CHARACTER SET utf8 NOT NULL,
  `jia4` text CHARACTER SET utf8 NOT NULL,
  `seo` text CHARACTER SET utf8 NOT NULL,
  `daili` float NOT NULL,
  `name` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `website`
--

INSERT INTO `website` (`id`, `logo`, `title`, `app1`, `app2`, `qq`, `tel`, `ipinfo`, `appleid1`, `appleps1`, `appleid2`, `appleps2`, `appleid3`, `appleps3`, `and_img1`, `and_img2`, `and_img3`, `and_img4`, `jia1`, `jia2`, `jia3`, `jia4`, `seo`, `daili`, `name`) VALUES
(0, 'http://localhost/web/images/logo.png', '云流量', '/xyrml.apk', '/openvpn.apk', '123123', '13800138001', '阿里云', 'aqytwbee@icloud.com', 'Aa778899', 'zxxzwcwo@icloud.com', 'Aa778899', 'xhxfspgv@icloud.com', 'Aa778899', 'http://localhost/web/images/slide_4.png', 'http://localhost/web/images/slide_5.png', 'http://localhost/web/images/slide_6.png', 'http://localhost/web/images/slide_7.png', '0', '5', '50', '200', '', 0, 'xyr');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;